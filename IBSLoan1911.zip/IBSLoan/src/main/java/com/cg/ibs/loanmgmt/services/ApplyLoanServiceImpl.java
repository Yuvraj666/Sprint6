package com.cg.ibs.loanmgmt.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.repositories.AccountDao;
import com.cg.ibs.loanmgmt.repositories.AccountHoldingDao;
import com.cg.ibs.loanmgmt.repositories.BankAdminsDao;
import com.cg.ibs.loanmgmt.repositories.DocumentDao;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;
import com.cg.ibs.loanmgmt.repositories.LoanTypeDao;

@Service
public class ApplyLoanServiceImpl implements ApplyLoanService {
	private static Logger LOGGER = Logger.getLogger(ApplyLoanServiceImpl.class);
	@Autowired
	private LoanTypeDao loanTypeDao;

	@Autowired
	private AccountHoldingDao accountHoldingDao;

	@Autowired
	private BankAdminsDao bankAdminsDao;

	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private DocumentDao documentDao;

	@Override
	public LoanTypeBean getLoanTypeByTypeID(Integer typeId) {
		LOGGER.info("Fetching loan type details");
		return loanTypeDao.getLoanTypeByTypeID(typeId);
	}

	@Override
	public LoanMaster calculateEmi(LoanMaster loanMaster) {
		LOGGER.info("Calculating EMI amount");
		Float rate = loanMaster.getLoanInterest() / (12 * 100);
		Double onePlusRPoweredN = Math.pow((rate + 1), loanMaster.getLoanTenure());
		BigDecimal principal = loanMaster.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		loanMaster.setEmiAmount(emi.setScale(2, BigDecimal.ROUND_UP));
		return loanMaster;
	}

	public BigDecimal calculatePaidInterest(LoanMaster loanMaster) {
		BigDecimal balance = loanMaster.getBalance();
		Float rate = loanMaster.getLoanInterest() / 100;
		BigDecimal paidInterest = (balance.multiply(BigDecimal.valueOf(Math.pow(1 + rate, 1.0 / 12.0)))
				.subtract(balance));
		return paidInterest;
	}

	public BigDecimal calculatePaidPrinciple(LoanMaster loanMaster) {

		BigDecimal paidPrinciple = loanMaster.getEmiAmount().subtract(calculatePaidInterest(loanMaster));
		return paidPrinciple;
	}

	public Set<AccountHolding> getSavingAccountListByUci(CustomerBean customer) {
		return accountHoldingDao.getSavingAccountListByUci(customer);
	}

	private BankAdmins appointBankAdmins() {
		List<BankAdmins> registeredBankAdmins = bankAdminsDao.getRegisteredBankAdmins();
		BankAdmins appointedAdmin;
		BigInteger maxApplicationNumber = loanMasterDao.getMaxApplicationNumber();
		LoanMaster latestLoan = loanMasterDao.getLoanByApplicantNumber(maxApplicationNumber);
		int lastBankAdminIndex = -1;
		lastBankAdminIndex = registeredBankAdmins.indexOf(latestLoan.getAdminApprover());
		if (lastBankAdminIndex == (registeredBankAdmins.size() - 1) || lastBankAdminIndex == -1) {
			appointedAdmin = registeredBankAdmins.get(0);
		}else {
			appointedAdmin = registeredBankAdmins.get(lastBankAdminIndex + 1);
		}
		return appointedAdmin;
	}
	@Override
	@Transactional
	public void appointBankAdminsToExistingLoans(List<LoanMaster> toUpdateLoans) {
		List<BankAdmins> registeredBankAdmins = bankAdminsDao.getRegisteredBankAdmins();
		BankAdmins appointedAdmin;
		List<LoanMaster> updatedLoans = new ArrayList<>();
		BigInteger maxApplicationNumber = loanMasterDao.getMaxApplicationNumber();
		LoanMaster latestLoan = loanMasterDao.getLoanByApplicantNumber(maxApplicationNumber);
		int lastBankAdminIndex = registeredBankAdmins.indexOf(latestLoan.getAdminApprover());
		if (lastBankAdminIndex == (registeredBankAdmins.size() - 1) || lastBankAdminIndex == -1) {
			appointedAdmin = registeredBankAdmins.get(0);
		}else {
			appointedAdmin = registeredBankAdmins.get(lastBankAdminIndex + 1);
		}
		int currentIndex;
		for (LoanMaster loanMaster : toUpdateLoans) {
			loanMaster.setAdminApprover(appointedAdmin);
			updatedLoans.add(loanMaster);
			currentIndex=registeredBankAdmins.indexOf(appointedAdmin);
			if (currentIndex == (registeredBankAdmins.size() - 1)) {
				appointedAdmin = registeredBankAdmins.get(0);
			}else {
				appointedAdmin = registeredBankAdmins.get(currentIndex + 1);
			}
		}
		loanMasterDao.updateLoanBankAdminApprover(updatedLoans);
	}

	@Override
	@Transactional
	public void sendLoanForVerification(LoanMaster globalLoanMaster, BigInteger accNo) {
		globalLoanMaster.setSavingsAccount(accountDao.getAccount(accNo));
		loanMasterDao.sendLoanForVerification(globalLoanMaster);

	}
	@Override
	@Transactional
	public void updateLoanForVerification(LoanMaster globalLoanMaster) {
		globalLoanMaster.setStatus(LoanStatus.SENT_FOR_VERIFICATION);
		globalLoanMaster.setAdminApprover(appointBankAdmins());
		loanMasterDao.updateLoanForVerification(globalLoanMaster);

	}
	@Override
	public Account getAccount(BigInteger accountNumber) {
		return accountDao.getAccount(accountNumber);
	}

	@Override
	@Transactional
	public DocumentBean uploadDocument(DocumentBean document) {
		System.out.println("service");
		return documentDao.uploadDocuments(document);
	}

}
