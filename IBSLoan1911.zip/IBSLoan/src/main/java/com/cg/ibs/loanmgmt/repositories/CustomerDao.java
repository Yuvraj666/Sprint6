package com.cg.ibs.loanmgmt.repositories;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface CustomerDao {
	CustomerBean getCustomerByUserId(String userId);
	
	public CustomerBean getCustomerDetailsByUci(BigInteger uci);

	List<LoanMaster> getLoanListByUci(CustomerBean customer);

}
