
package com.cg.ibs.loanmgmt.controllers;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanType;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;

@Controller
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;

	BankAdmins loggedInBankAdmin = new BankAdmins();
	LoanMaster globalLoanMaster = new LoanMaster();

	@RequestMapping(method = RequestMethod.GET, value = "/bankAdmin")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		loggedInBankAdmin = bankAdminService.getBankAdmin(userId);
		modelAndView.addObject("loginVerified", "Welcome " + loggedInBankAdmin.getAdminId());
		modelAndView.setViewName("loggedinBankAdminPage");
		return modelAndView;
	}

	@RequestMapping(value = "/verifyLoan")
	public ModelAndView viewPendingLoans() {
		Set<LoanMaster> tempSet = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
		List<LoanMaster> pendingLoans = new ArrayList<>();
		List<CustomerBean> pendingLoanCustomers = new ArrayList<>();
		List<LoanTypeBean> pendingLoanTypes = new ArrayList<>();
		for (LoanMaster loanMaster : tempSet) {
			pendingLoans.add(loanMaster);
			pendingLoanCustomers.add(customerService.getCustomerDetailsByUci(loanMaster.getUci()));
			pendingLoanTypes.add(applyLoanService.getLoanTypeByTypeID(loanMaster.getTypeId()));
		}

		ModelAndView mv = new ModelAndView();
		mv.addObject("pendingLoans", pendingLoans);
		mv.addObject("pendingLoanCustomers", pendingLoanCustomers);
		mv.addObject("pendingLoanTypes", pendingLoanTypes);
		mv.setViewName("verifyLoanPage");
		return mv;
	}

	@RequestMapping(value = "/verifyLoan1")
	public ModelAndView selectLoanVerify(@RequestParam("loanApplicationNumber") BigInteger loanApplicationNumber) {
		globalLoanMaster.setApplicationNumber(loanApplicationNumber);
		System.out.println(globalLoanMaster.getApplicationNumber());
		return new ModelAndView("verifyLoanPage", "lApplicationNo", globalLoanMaster.getApplicationNumber());
	}

	@RequestMapping(value = "/verifyLoan2")
	public ModelAndView viewCompleteDetails() {
		globalLoanMaster = verifyLoanService.getLoanByApplicantNum(globalLoanMaster.getApplicationNumber());
		return new ModelAndView("verifyLoanPage", "lMaster", globalLoanMaster);

	}

	@RequestMapping(value = "/verifyLoan3")
	public ModelAndView downloadDoc() {
		return null;
	}

	@RequestMapping(value = "/verifyLoan4")
	public ModelAndView updateLoanPostVerify(@RequestParam("appLoan") Integer choice) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("verifyLoanPage");
		if (choice == 1) {
			globalLoanMaster.setStatus(LoanStatus.APPROVED);
			globalLoanMaster.setApprovedDate(LocalDate.now());
			globalLoanMaster.setNextEmiDate(LocalDate.now().plusMonths(1));
			globalLoanMaster.setTotalNumOfEmis(globalLoanMaster.getLoanTenure());
			globalLoanMaster.setNumOfEmisPaid(0);
			globalLoanMaster.getSavingsAccount().setBalance(globalLoanMaster.getLoanAmount());
			globalLoanMaster = verifyLoanService.updateLoanPostVerify(globalLoanMaster);
			modelAndView.addObject("msgupdate",
					"Loan has been approved with loan number" + globalLoanMaster.getApplicationNumber());
		} else {
			globalLoanMaster.setStatus(LoanStatus.DENIED);
			globalLoanMaster = verifyLoanService.updateLoanPostDenial(globalLoanMaster);
			modelAndView.addObject("msgupdate", "Loan has been declined.");
		}
		return modelAndView;
	}
}
