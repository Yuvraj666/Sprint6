package com.cg.ibs.loanmgmt.models;

public enum AccountStatus {
	ACTIVE, CLOSED;
}