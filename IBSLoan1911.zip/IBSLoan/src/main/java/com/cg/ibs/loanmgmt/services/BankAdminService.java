package com.cg.ibs.loanmgmt.services;

import com.cg.ibs.loanmgmt.models.BankAdmins;

public interface BankAdminService {
	boolean verifyBankLogin(String userId, String password);

	BankAdmins getBankAdmin(String userId);
}
