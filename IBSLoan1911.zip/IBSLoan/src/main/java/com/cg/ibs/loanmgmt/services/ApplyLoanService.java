package com.cg.ibs.loanmgmt.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;

public interface ApplyLoanService {
	LoanTypeBean getLoanTypeByTypeID(Integer typeId);

	LoanMaster calculateEmi(LoanMaster loanMaster);

	BigDecimal calculatePaidInterest(LoanMaster loanMaster);

	BigDecimal calculatePaidPrinciple(LoanMaster loanMaster);

	Set<AccountHolding> getSavingAccountListByUci(CustomerBean customer);

	void sendLoanForVerification(LoanMaster globalLoanMaster, BigInteger accNo);

	Account getAccount(BigInteger accountNumber);

	DocumentBean uploadDocument(DocumentBean document);

	void updateLoanForVerification(LoanMaster globalLoanMaster);

	void appointBankAdminsToExistingLoans(List<LoanMaster> toUpdateLoans);
}
