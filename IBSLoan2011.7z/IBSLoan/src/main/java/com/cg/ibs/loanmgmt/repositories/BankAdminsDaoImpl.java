package com.cg.ibs.loanmgmt.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;

@Repository("BankAdminsDao")
public class BankAdminsDaoImpl implements BankAdminsDao {
	private static Logger LOGGER = Logger.getLogger(BankAdminsDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public BankAdmins getAdminByUserId(String adminId) {
		LOGGER.info("Fetching customer details");
		BankAdmins bankAdmins = new BankAdmins();
		try {
			TypedQuery<BankAdmins> query = entityManager.createQuery("select b from BankAdmins b where b.adminId=?1",
					BankAdmins.class);
			query.setParameter(1, adminId);
			bankAdmins = (BankAdmins) query.getSingleResult();
		} catch (NoResultException exp) {
			bankAdmins = null;
		}
		return bankAdmins;
	}

	@Override
	public List<BankAdmins> getRegisteredBankAdmins() {
		LOGGER.info("fetch all registered bank admins");
		TypedQuery<BankAdmins> query = entityManager.createQuery("Select b from BankAdmins b", BankAdmins.class);
		List<BankAdmins> registeredBankAdmins = query.getResultList();
		return registeredBankAdmins;
	}

}
