package com.cg.ibs.loanmgmt.repositories;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;

@Repository("Accountholding")
public class AccountHoldingDaoImpl implements AccountHoldingDao {
	private static Logger LOGGER = Logger.getLogger(AccountHoldingDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public Set<AccountHolding> getSavingAccountListByUci(CustomerBean customer) {
		LOGGER.info("Fetching Savings Account Related to User ID");
		TypedQuery<AccountHolding> query = entityManager.createQuery("select c from AccountHolding c where c.customer=?1",
				AccountHolding.class);
		query.setParameter(1, customer);
		List<AccountHolding> setTemp = query.getResultList();
		Set<AccountHolding> savingsAccount = new HashSet<>();
		for (AccountHolding accountHolding : setTemp) {
			savingsAccount.add(accountHolding);
		}
		return savingsAccount;
	}

}
