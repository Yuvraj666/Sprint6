package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.BankAdminsDao;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;

@Service
public class VerifyLoanServiceImpl implements VerifyLoanService{
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private BankAdminsDao bankAdminsDao;
	@Autowired
	private ApplyLoanService applyLoanService;
	
	public Set<LoanMaster> getSentForVerificationLoans(BankAdmins loggedInBankAdmin) {
		appointBankAdminIfChanged();
		List<LoanMaster> listTemp = null;
		listTemp =	loanMasterDao.getSentForVerificationLoans(loggedInBankAdmin);
		Set<LoanMaster> pendingApplications = new HashSet<>();
		for (LoanMaster loanMaster : listTemp) {
			pendingApplications.add(loanMaster);
		}
		return pendingApplications;
	}
	
	private void appointBankAdminIfChanged(){
		boolean check = false;
		List<LoanMaster> allLoans = loanMasterDao.getAllLoans();
		List<BankAdmins> registeredAdmins = bankAdminsDao.getRegisteredBankAdmins();
		List<LoanMaster> toUpdateLoans = new ArrayList<>();
		for (LoanMaster loanMaster : allLoans) {
			check=false;
			for (BankAdmins bankAdmins : registeredAdmins) {
				if(loanMaster.getAdminApprover().equals(bankAdmins)) {
					check = true;
					break;
				}
			}
			if(!check)
			{
				toUpdateLoans.add(loanMaster);
			}
		}
		applyLoanService.appointBankAdminsToExistingLoans(toUpdateLoans);
	}
	
	@Override
	public LoanMaster getLoanByApplicantNum(BigInteger applicantNum) {
		return loanMasterDao.getLoanByApplicantNumber(applicantNum);
	}

	
	
}
