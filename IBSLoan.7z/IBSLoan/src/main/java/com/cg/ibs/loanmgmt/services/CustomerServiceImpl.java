package com.cg.ibs.loanmgmt.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.repositories.CustomerDao;

@Service
public class CustomerServiceImpl implements CustomerService {
	private static Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);

	@Autowired
	private CustomerDao customerDao;

	@Override
	public boolean verifyCustomerLogin(String userId, String password) {
		LOGGER.info("Verifying customer login details");
		boolean login = false;
		CustomerBean customer = customerDao.getCustomerByUserId(userId);
		if (null != customer && password.equals(customer.getPassword())) {
			login = true;
		}
		return login;
	}

	@Override
	public CustomerBean getCustomer(String userId) {
		LOGGER.info("Fetching customer details");
		return customerDao.getCustomerByUserId(userId);
	}

}
