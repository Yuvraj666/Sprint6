package com.cg.ibs.loanmgmt.services;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.repositories.AccountHoldingDao;
import com.cg.ibs.loanmgmt.repositories.LoanTypeDao;

@Service
public class ApplyLoanServiceImpl implements ApplyLoanService {
	private static Logger LOGGER = Logger.getLogger(ApplyLoanServiceImpl.class);
	@Autowired
	private LoanTypeDao loanTypeDao;
	
	@Autowired
	private AccountHoldingDao accountHoldingDao;
	
	@Override
	public LoanTypeBean getLoanTypeByTypeID(Integer typeId) {
		LOGGER.info("Fetching loan type details");
		return loanTypeDao.getLoanTypeByTypeID(typeId);
	}

	@Override
	public LoanMaster calculateEmi(LoanMaster loanMaster) {
		LOGGER.info("Calculating EMI amount");
		Float rate = loanMaster.getLoanInterest() / (12 * 100);
		Double onePlusRPoweredN = Math.pow((rate + 1), loanMaster.getLoanTenure());
		BigDecimal principal = loanMaster.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		loanMaster.setEmiAmount(emi.setScale(2, BigDecimal.ROUND_UP));
		return loanMaster;
	}

	public BigDecimal calculatePaidInterest(LoanMaster loanMaster) {
		BigDecimal balance = loanMaster.getBalance();
		Float rate = loanMaster.getLoanInterest() / 100;
		BigDecimal paidInterest = (balance.multiply(BigDecimal.valueOf(Math.pow(1 + rate, 1.0 / 12.0)))
				.subtract(balance));
		return paidInterest;
	}

	public BigDecimal calculatePaidPrinciple(LoanMaster loanMaster) {

		BigDecimal paidPrinciple = loanMaster.getEmiAmount().subtract(calculatePaidInterest(loanMaster));
		return paidPrinciple;
	}
	
	public List<AccountHolding> getSavingAccountListByUci(CustomerBean customer) {
		return accountHoldingDao.getSavingAccountListByUci(customer);
	}

}
