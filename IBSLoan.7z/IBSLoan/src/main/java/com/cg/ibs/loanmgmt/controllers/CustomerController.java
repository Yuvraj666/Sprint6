package com.cg.ibs.loanmgmt.controllers;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanDetailsDisplay;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.CustomerService;

@Controller
@Scope("session")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	private LoanTypeBean loanTypeBean = new LoanTypeBean();
	CustomerBean loggedInCustomer = new CustomerBean();
	private ModelAndView modelAndView = new ModelAndView();
	private LoanMaster globalLoanMaster = new LoanMaster();
	
	@RequestMapping(method = RequestMethod.GET, value = "/customer")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		loggedInCustomer = customerService.getCustomer(userId);
		modelAndView.addObject("loginVerified", "Welcome " + customerService.getCustomer(userId).getFirstName());
		modelAndView.setViewName("loggedinCustomerPage");
		return modelAndView;
	}

	@RequestMapping(value = "/addLoan", method = RequestMethod.GET)
	public String showNewDeptPage() {
		return "addLoan";
	}

	@RequestMapping(value = "/homeCalculateEMI")
	public ModelAndView getDetailsForHomeLoan() {
		Integer typeId = 1;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		modelAndView.setViewName("homeCalculateEMI");
		globalLoanMaster.setTypeId(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		return modelAndView;
	}

	@RequestMapping(value = "/homeCalculateEMI2")
	public ModelAndView calculateEmi(@ModelAttribute LoanMaster loanMaster) {
		loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
		globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
		globalLoanMaster.setBalance(loanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
		modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
		modelAndView.setViewName("homeCalculateEMI");
		return modelAndView;

	}

	@RequestMapping(value = "/homeCalculateEMI3")
	public ModelAndView displayTable() {
		List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
		LoanMaster loanMaster = globalLoanMaster;
		for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
			BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4, RoundingMode.HALF_UP);
			BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
					RoundingMode.HALF_UP);
			loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
			LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
			tableList.add(display);
		}
		return new ModelAndView("homeCalculateEMI", "tableDisplay", tableList);
	}

	@RequestMapping(value = "/savingsAccountDetails")
	public ModelAndView getSavingsAccount() {
		loggedInCustomer.setAccountHoldings(applyLoanService.getSavingAccountListByUci(loggedInCustomer));
		return new ModelAndView("savingsAccountDetailsPage", "tableList", loggedInCustomer.getAccountHoldings());

	}

	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView uploadMultipleFileHandler(@RequestParam("file") MultipartFile[] files) {

	
		String message = "";
		for (int i = 0; i < files.length; i++) {
			DocumentBean document = new DocumentBean();
			document.setApplicationNumber(globalLoanMaster.getApplicationNumber());
			MultipartFile file = files[i];
			System.out.println("Inside Loop");
			try {
				byte[] bytes = file.getBytes();
				if (i == 0) {
					document.setAadharCard(bytes);
				} else if (i == 1) {
					if (globalLoanMaster.getTypeId() == 1) {
						document.setProperty_collateral(bytes);
						System.out.println("inside home");
					}
					if (globalLoanMaster.getTypeId() == 2) {
						document.setAdmissionLetter(bytes);
					}
					if (globalLoanMaster.getTypeId() == 3) {
						document.setPanCard(bytes);
					}
					if (globalLoanMaster.getTypeId() == 4) {
						document.setVehicleRc(bytes);
					}
				}
				message = message + "You successfully uploaded file!";
				applyLoanService.uploadDocument(document);
			} catch (Exception e) {
				message= "You failed to upload " + e.getMessage();
			}
		}
		applyLoanService.updateLoanForVerification(globalLoanMaster);
		return new ModelAndView("uploadFilePage","message",message);
	}

	@RequestMapping(value = "/loanApplied")
	public ModelAndView loanSentForVerify(@RequestParam("optRadio") BigInteger accNo) {
		System.out.println("Inside appNUm");
		globalLoanMaster.setStatus(LoanStatus.DOCUMENT_PENDING);
		globalLoanMaster.setBalance(globalLoanMaster.getLoanAmount());
		globalLoanMaster.setAppliedDate(LocalDate.now());
		globalLoanMaster.setUci(loggedInCustomer.getUci());
		applyLoanService.sendLoanForVerification(globalLoanMaster, accNo);
		
		System.out.println(globalLoanMaster.getApplicationNumber());

		return new ModelAndView("loanAppliedPage", "appNum", globalLoanMaster.getApplicationNumber());

	}


	@RequestMapping("/loanAppliedPage")
	public String loanApplied() {
		return "loanAppliedPage";
	}

	@RequestMapping(value = "/submit")
	public ModelAndView successUpload() {

		return modelAndView;

	}
}
