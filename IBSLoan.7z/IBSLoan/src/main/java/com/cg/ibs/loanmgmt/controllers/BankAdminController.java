
package com.cg.ibs.loanmgmt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.services.BankAdminService;

@Controller
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	
	BankAdmins bankAdmin = new BankAdmins();

	@RequestMapping(method = RequestMethod.GET, value = "/bankAdmin")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		bankAdmin = bankAdminService.getBankAdmin(userId);
		modelAndView.addObject("loginVerified", "Welcome "+bankAdmin.getAdminId());
		modelAndView.setViewName("loggedinBankAdminPage");
		return modelAndView;
	}
}
