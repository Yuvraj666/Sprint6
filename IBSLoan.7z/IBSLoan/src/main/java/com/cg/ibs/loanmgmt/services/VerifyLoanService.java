package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface VerifyLoanService {

	Set<LoanMaster> getSentForVerificationLoans(BankAdmins loggedInBankAdmin);

	LoanMaster getLoanByApplicantNum(BigInteger applicantNum);
}
