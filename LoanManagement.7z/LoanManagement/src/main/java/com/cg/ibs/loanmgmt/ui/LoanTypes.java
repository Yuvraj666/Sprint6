package com.cg.ibs.loanmgmt.ui;

public enum LoanTypes {
		HOME_LOAN,EDUCATION_LOAN,PERSONAL_LOAN,VEHICLE_LOAN, GO_BACK
}
