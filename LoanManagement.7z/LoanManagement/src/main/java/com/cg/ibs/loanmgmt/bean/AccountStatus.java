package com.cg.ibs.loanmgmt.bean;

public enum AccountStatus {
	ACTIVE, CLOSED;
}